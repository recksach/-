package com.reck.camsansung.camera

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Log
import androidx.camera.core.Camera
import androidx.camera.core.CameraEffect
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.SurfaceOrientedMeteringPointFactory
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.reck.camsansung.presets.Preset
import java.text.SimpleDateFormat
import java.util.Locale

class CameraXManager(private val context: Context) {

    private var cameraProvider: ProcessCameraProvider? = null
    private var extensionsManager: ExtensionsManager? = null
    private var camera: Camera? = null

    private var preview: Preview? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var activeRecording: Recording? = null

    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var extensionMode = ExtensionMode.NONE

    val colorProcessor = ColorGradeSurfaceProcessor()

    fun applyPreset(preset: Preset) {
        colorProcessor.currentPreset = preset
    }

    /** Suspend-free callback-based bind since CameraX's own listenable future
     *  already hops onto the main executor for us. */
    fun start(
        lifecycleOwner: LifecycleOwner,
        previewView: PreviewView,
        onReady: () -> Unit,
        onError: (Throwable) -> Unit
    ) {
        val providerFuture = ProcessCameraProvider.getInstance(context)
        providerFuture.addListener({
            try {
                cameraProvider = providerFuture.get()
                val extFuture = ExtensionsManager.getInstanceAsync(context, cameraProvider!!)
                extFuture.addListener({
                    extensionsManager = extFuture.get()
                    bindUseCases(lifecycleOwner, previewView)
                    onReady()
                }, ContextCompat.getMainExecutor(context))
            } catch (t: Throwable) {
                onError(t)
            }
        }, ContextCompat.getMainExecutor(context))
    }

    /** true if the vendor's dedicated HDR/Night pipeline is available on this
     *  device for the currently selected lens (A34's ISP exposes these on the
     *  main rear camera). Falls back gracefully if not present. */
    fun isNightExtensionAvailable(): Boolean {
        if (cameraProvider == null) return false
        val selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
        return extensionsManager?.isExtensionAvailable(selector, ExtensionMode.NIGHT) == true
    }

    fun isHdrExtensionAvailable(): Boolean {
        if (cameraProvider == null) return false
        val selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
        return extensionsManager?.isExtensionAvailable(selector, ExtensionMode.HDR) == true
    }

    fun setExtensionMode(mode: Int, lifecycleOwner: LifecycleOwner, previewView: PreviewView) {
        extensionMode = mode
        bindUseCases(lifecycleOwner, previewView)
    }

    fun switchCamera(lifecycleOwner: LifecycleOwner, previewView: PreviewView) {
        lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK)
            CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
        bindUseCases(lifecycleOwner, previewView)
    }

    private fun bindUseCases(lifecycleOwner: LifecycleOwner, previewView: PreviewView) {
        val provider = cameraProvider ?: return
        provider.unbindAll()

        var selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
        if (extensionMode != ExtensionMode.NONE && extensionsManager?.isExtensionAvailable(selector, extensionMode) == true) {
            selector = extensionsManager!!.getExtensionEnabledCameraSelector(selector, extensionMode)
        }

        preview = Preview.Builder().build().also {
            it.setSurfaceProvider(previewView.surfaceProvider)
        }
        imageCapture = ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
            .build()

        val recorder = Recorder.Builder()
            .setQualitySelector(QualitySelector.fromOrderedList(
                listOf(Quality.UHD, Quality.FHD, Quality.HD),
                androidx.camera.video.FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)
            ))
            .build()
        videoCapture = VideoCapture.withOutput(recorder)

        val effect = object : CameraEffect(
            CameraEffect.PREVIEW or CameraEffect.VIDEO_CAPTURE,
            ContextCompat.getMainExecutor(context),
            colorProcessor,
            { throwable -> Log.e(TAG, "Color-grade effect error", throwable) }
        ) {}

        val useCaseGroupBuilder = androidx.camera.core.UseCaseGroup.Builder()
            .addUseCase(preview!!)
            .addUseCase(imageCapture!!)
            .addUseCase(videoCapture!!)
            .addEffect(effect)

        camera = provider.bindToLifecycle(lifecycleOwner, selector, useCaseGroupBuilder.build())
    }

    fun tapToFocus(previewView: PreviewView, x: Float, y: Float) {
        val cam = camera ?: return
        val factory = SurfaceOrientedMeteringPointFactory(previewView.width.toFloat(), previewView.height.toFloat())
        val point = factory.createPoint(x, y)
        val action = FocusMeteringAction.Builder(point).build()
        cam.cameraControl.startFocusAndMetering(action)
    }

    fun setZoom(ratio: Float) {
        camera?.cameraControl?.setZoomRatio(ratio)
    }

    fun setTorch(on: Boolean) {
        camera?.cameraControl?.enableTorch(on)
    }

    fun hasFlash(): Boolean = camera?.cameraInfo?.hasFlashUnit() == true

    fun takePhoto(onSaved: (Uri) -> Unit, onError: (ImageCaptureException) -> Unit) {
        val capture = imageCapture ?: return
        val name = "CAM_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())}"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Camsansung")
            }
        }
        val outputOptions = ImageCapture.OutputFileOptions.Builder(
            context.contentResolver,
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            values
        ).build()

        capture.takePicture(
            outputOptions,
            ContextCompat.getMainExecutor(context),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    output.savedUri?.let(onSaved)
                }
                override fun onError(exception: ImageCaptureException) {
                    onError(exception)
                }
            }
        )
    }

    fun startRecording(
        withAudio: Boolean,
        onStarted: () -> Unit,
        onFinished: (Uri?) -> Unit,
        onError: (String) -> Unit
    ) {
        val videoCap = videoCapture ?: return
        val name = "VID_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())}"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Camsansung")
            }
        }
        val outputOptions = MediaStoreOutputOptions.Builder(
            context.contentResolver,
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(values).build()

        var pendingRecording = videoCap.output.prepareRecording(context, outputOptions)
        if (withAudio) {
            pendingRecording = pendingRecording.withAudioEnabled()
        }

        activeRecording = pendingRecording.start(ContextCompat.getMainExecutor(context)) { event ->
            when (event) {
                is VideoRecordEvent.Start -> onStarted()
                is VideoRecordEvent.Finalize -> {
                    if (!event.hasError()) {
                        onFinished(event.outputResults.outputUri)
                    } else {
                        onError("Ошибка записи: код ${event.error}")
                    }
                    activeRecording = null
                }
                else -> Unit
            }
        }
    }

    fun stopRecording() {
        activeRecording?.stop()
        activeRecording = null
    }

    fun isRecording(): Boolean = activeRecording != null

    fun release() {
        colorProcessor.release()
        cameraProvider?.unbindAll()
    }

    companion object {
        private const val TAG = "CameraXManager"
    }
}

package com.reck.camsansung.presets

object PresetRepository {

    /** "Standard" is the baseline — sharpen/denoise auto-enhance stays on,
     *  no color grading, so it's a fair, honest "better than stock" mode. */
    val STANDARD = Preset(
        id = "standard",
        displayName = "Стандарт+",
        sharpen = 0.4f,
        contrast = 1.05f,
        saturation = 1.05f
    )

    val CINEMATIC_TEAL_ORANGE = Preset(
        id = "teal_orange",
        displayName = "Cinema Teal",
        temperature = 0.12f,
        tint = -0.05f,
        contrast = 1.22f,
        saturation = 1.18f,
        vignette = 0.35f,
        grain = 0.12f,
        sharpen = 0.45f,
        aspectRatio = 2.39f,
        fadeBlacks = 0.18f
    )

    val CINEMATIC_MOODY_BLUE = Preset(
        id = "moody_blue",
        displayName = "Moody Blue",
        temperature = -0.25f,
        tint = 0.04f,
        contrast = 1.3f,
        saturation = 0.85f,
        exposure = -0.08f,
        vignette = 0.45f,
        grain = 0.15f,
        sharpen = 0.4f,
        aspectRatio = 2.39f,
        fadeBlacks = 0.1f
    )

    val NOIR_BW = Preset(
        id = "noir",
        displayName = "Noir",
        contrast = 1.45f,
        saturation = 0f,
        vignette = 0.5f,
        grain = 0.22f,
        sharpen = 0.5f,
        aspectRatio = 1.85f,
        monochrome = true
    )

    val VIVID_HDR = Preset(
        id = "vivid_hdr",
        displayName = "Vivid HDR",
        contrast = 1.15f,
        saturation = 1.35f,
        exposure = 0.05f,
        sharpen = 0.55f
    )

    val GOLDEN_HOUR = Preset(
        id = "golden_hour",
        displayName = "Golden Hour",
        temperature = 0.3f,
        tint = -0.02f,
        contrast = 1.12f,
        saturation = 1.2f,
        exposure = 0.06f,
        vignette = 0.2f,
        sharpen = 0.4f,
        fadeBlacks = 0.12f
    )

    val VINTAGE_FILM = Preset(
        id = "vintage_film",
        displayName = "Vintage 16mm",
        temperature = 0.08f,
        tint = 0.06f,
        contrast = 0.95f,
        saturation = 0.8f,
        vignette = 0.4f,
        grain = 0.35f,
        sharpen = 0.25f,
        aspectRatio = 1.66f,
        fadeBlacks = 0.25f
    )

    val ALL: List<Preset> = listOf(
        STANDARD,
        CINEMATIC_TEAL_ORANGE,
        CINEMATIC_MOODY_BLUE,
        NOIR_BW,
        VIVID_HDR,
        GOLDEN_HOUR,
        VINTAGE_FILM
    )

    fun byId(id: String): Preset = ALL.firstOrNull { it.id == id } ?: STANDARD
}

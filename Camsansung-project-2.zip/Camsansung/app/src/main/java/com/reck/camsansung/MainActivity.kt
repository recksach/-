package com.reck.camsansung

import android.animation.ValueAnimator
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.reck.camsansung.camera.CameraXManager
import com.reck.camsansung.databinding.ActivityMainBinding
import com.reck.camsansung.presets.Preset
import com.reck.camsansung.presets.PresetRepository
import com.reck.camsansung.ui.PresetAdapter
import com.reck.camsansung.util.PermissionsHelper
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var cameraManager: CameraXManager

    private enum class CaptureMode { CINEMA, VIDEO, PHOTO }
    private var currentMode = CaptureMode.PHOTO
    private var currentPreset: Preset = PresetRepository.STANDARD

    private var recordingSeconds = 0
    private var recordingTicker: Runnable? = null
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.all { it }) {
            onPermissionsGranted()
        } else {
            binding.permissionText.text = getString(R.string.permission_denied)
            binding.btnGrant.text = getString(R.string.open_settings)
            binding.btnGrant.setOnClickListener { openAppSettings() }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        cameraManager = CameraXManager(applicationContext)

        setupPresetCarousel()
        setupModeSwitch()
        setupShutter()
        setupTopBar()
        setupGestures()

        if (PermissionsHelper.allGranted(this)) {
            onPermissionsGranted()
        } else {
            showPermissionPanel()
        }
    }

    // ---------------------------------------------------------------------
    // Permissions
    // ---------------------------------------------------------------------

    private fun showPermissionPanel() {
        binding.permissionPanel.isVisible = true
        binding.btnGrant.text = getString(R.string.grant)
        binding.btnGrant.setOnClickListener {
            permissionLauncher.launch(PermissionsHelper.requiredPermissions())
        }
    }

    private fun onPermissionsGranted() {
        binding.permissionPanel.isVisible = false
        startCamera()
    }

    private fun openAppSettings() {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", packageName, null)
        }
        startActivity(intent)
    }

    // ---------------------------------------------------------------------
    // Camera lifecycle
    // ---------------------------------------------------------------------

    private fun startCamera() {
        cameraManager.start(
            lifecycleOwner = this,
            previewView = binding.previewView,
            onReady = {
                cameraManager.applyPreset(currentPreset)
                updateHdrBadge()
                binding.btnFlash.isVisible = cameraManager.hasFlash()
            },
            onError = { t ->
                Toast.makeText(this, "Камера недоступна: ${t.message}", Toast.LENGTH_LONG).show()
            }
        )
    }

    private fun updateHdrBadge() {
        val available = cameraManager.isHdrExtensionAvailable() || cameraManager.isNightExtensionAvailable()
        binding.hdrBadge.isVisible = available
        binding.hdrBadge.text = if (cameraManager.isNightExtensionAvailable())
            getString(R.string.night_on) else getString(R.string.hdr_on)
    }

    // ---------------------------------------------------------------------
    // Presets
    // ---------------------------------------------------------------------

    private fun setupPresetCarousel() {
        binding.presetRecycler.layoutManager =
            LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
        binding.presetRecycler.adapter = PresetAdapter(PresetRepository.ALL) { preset ->
            currentPreset = preset
            cameraManager.applyPreset(preset)
            applyLetterbox(preset.aspectRatio)
        }
    }

    /** Draws black mattes top/bottom so the frame reads as the preset's
     *  cinematic aspect ratio (e.g. 2.39:1) without cropping/upscaling the
     *  sensor output — purely a compositional guide, full resolution is
     *  still recorded underneath. */
    private fun applyLetterbox(aspectRatio: Float?) {
        binding.previewView.post {
            val viewW = binding.previewView.width
            val viewH = binding.previewView.height
            if (viewW == 0 || viewH == 0) return@post

            val targetBarHeight = if (aspectRatio == null) {
                0
            } else {
                val fullRatio = viewW.toFloat() / viewH.toFloat()
                if (aspectRatio > fullRatio) {
                    // wider than screen -> bars needed
                    val visibleHeight = viewW / aspectRatio
                    ((viewH - visibleHeight) / 2f).toInt().coerceAtLeast(0)
                } else 0
            }
            animateBarHeight(binding.letterboxTop, targetBarHeight)
            animateBarHeight(binding.letterboxBottom, targetBarHeight)
        }
    }

    private fun animateBarHeight(view: View, targetHeight: Int) {
        val start = view.layoutParams.height.coerceAtLeast(0)
        ValueAnimator.ofInt(start, targetHeight).apply {
            duration = 220
            addUpdateListener {
                view.layoutParams = view.layoutParams.apply { height = it.animatedValue as Int }
            }
            start()
        }
    }

    // ---------------------------------------------------------------------
    // Mode switch (Cinema / Video / Photo)
    // ---------------------------------------------------------------------

    private fun setupModeSwitch() {
        binding.modePhoto.setOnClickListener { selectMode(CaptureMode.PHOTO) }
        binding.modeVideo.setOnClickListener { selectMode(CaptureMode.VIDEO) }
        binding.modeCinema.setOnClickListener { selectMode(CaptureMode.CINEMA) }
        selectMode(CaptureMode.PHOTO)
    }

    private fun selectMode(mode: CaptureMode) {
        if (cameraManager.isRecording()) return
        currentMode = mode
        binding.modePhoto.alpha = if (mode == CaptureMode.PHOTO) 1f else 0.55f
        binding.modeVideo.alpha = if (mode == CaptureMode.VIDEO) 1f else 0.55f
        binding.modeCinema.alpha = if (mode == CaptureMode.CINEMA) 1f else 0.55f

        binding.shutterInner.setBackgroundResource(
            if (mode == CaptureMode.PHOTO) R.drawable.bg_shutter_inner_photo
            else R.drawable.bg_shutter_inner_video
        )

        // CINEMA mode nudges toward a graded, wide-aspect preset by default
        // if the user is still on the flat "Standard+" look.
        if (mode == CaptureMode.CINEMA && currentPreset.id == PresetRepository.STANDARD.id) {
            currentPreset = PresetRepository.CINEMATIC_TEAL_ORANGE
            cameraManager.applyPreset(currentPreset)
            applyLetterbox(currentPreset.aspectRatio)
        }
    }

    // ---------------------------------------------------------------------
    // Shutter
    // ---------------------------------------------------------------------

    private fun setupShutter() {
        binding.shutterButton.setOnClickListener {
            when (currentMode) {
                CaptureMode.PHOTO -> takePhoto()
                CaptureMode.VIDEO, CaptureMode.CINEMA -> toggleRecording()
            }
        }
    }

    private fun takePhoto() {
        flashShutterFeedback()
        cameraManager.takePhoto(
            onSaved = { uri ->
                Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show()
            },
            onError = { e ->
                Toast.makeText(this, "Ошибка съёмки: ${e.message}", Toast.LENGTH_LONG).show()
            }
        )
    }

    private fun flashShutterFeedback() {
        binding.previewView.animate().alpha(0.6f).setDuration(60).withEndAction {
            binding.previewView.animate().alpha(1f).setDuration(90).start()
        }.start()
    }

    private fun toggleRecording() {
        if (cameraManager.isRecording()) {
            cameraManager.stopRecording()
        } else {
            cameraManager.startRecording(
                withAudio = true,
                onStarted = {
                    binding.shutterInner.setBackgroundResource(R.drawable.bg_shutter_inner_recording)
                    startRecTimer()
                    binding.modePhoto.isEnabled = false
                },
                onFinished = { uri ->
                    stopRecTimer()
                    binding.shutterInner.setBackgroundResource(R.drawable.bg_shutter_inner_video)
                    binding.modePhoto.isEnabled = true
                    Toast.makeText(this, "Видео сохранено", Toast.LENGTH_SHORT).show()
                },
                onError = { msg ->
                    stopRecTimer()
                    binding.shutterInner.setBackgroundResource(R.drawable.bg_shutter_inner_video)
                    Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                }
            )
        }
    }

    private fun startRecTimer() {
        recordingSeconds = 0
        binding.recTimer.isVisible = true
        recordingTicker = object : Runnable {
            override fun run() {
                binding.recTimer.text = String.format(
                    Locale.US, "%02d:%02d", recordingSeconds / 60, recordingSeconds % 60
                )
                recordingSeconds++
                handler.postDelayed(this, 1000)
            }
        }
        handler.post(recordingTicker!!)
    }

    private fun stopRecTimer() {
        recordingTicker?.let { handler.removeCallbacks(it) }
        recordingTicker = null
        binding.recTimer.isVisible = false
    }

    // ---------------------------------------------------------------------
    // Top bar: flash toggle, flip camera
    // ---------------------------------------------------------------------

    private var torchOn = false

    private fun setupTopBar() {
        binding.btnFlash.setOnClickListener {
            torchOn = !torchOn
            cameraManager.setTorch(torchOn)
            binding.btnFlash.alpha = if (torchOn) 1f else 0.6f
        }
        binding.btnFlip.setOnClickListener {
            cameraManager.switchCamera(this, binding.previewView)
        }
        binding.btnSettings.setOnClickListener {
            Toast.makeText(this, "Настройки качества: скоро", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------------------------------------------------------------------
    // Gestures: tap-to-focus, pinch-to-zoom
    // ---------------------------------------------------------------------

    private var currentZoom = 1f

    private fun setupGestures() {
        val scaleDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                currentZoom = (currentZoom * detector.scaleFactor).coerceIn(1f, 8f)
                cameraManager.setZoom(currentZoom)
                return true
            }
        })
        val gestureDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                cameraManager.tapToFocus(binding.previewView, e.x, e.y)
                return true
            }
        })
        binding.previewView.setOnTouchListener { _, event ->
            scaleDetector.onTouchEvent(event)
            gestureDetector.onTouchEvent(event)
            true
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraManager.release()
    }
}

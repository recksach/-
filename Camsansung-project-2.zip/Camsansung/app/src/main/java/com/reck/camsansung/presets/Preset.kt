package com.reck.camsansung.presets

/**
 * One visual "look". All values feed straight into the GLES fragment shader
 * (see camera/ShaderPrograms.kt) so the SAME preset is applied identically to:
 *  - the live viewfinder,
 *  - the saved photo,
 *  - the recorded video,
 * which is what makes the result WYSIWYG and prevents any extra re-encode /
 * quality-losing post pass later.
 *
 * @param temperature  -1 (cold/blue) .. +1 (warm/orange)
 * @param tint         -1 (green) .. +1 (magenta)
 * @param contrast     0.5 (flat) .. 1.6 (punchy)
 * @param saturation   0 (b/w) .. 2 (vivid)
 * @param exposure     -1 (darker) .. +1 (brighter), applied as EV stop fraction
 * @param vignette     0 (off) .. 1 (strong dark corners)
 * @param grain        0 (off) .. 1 (heavy film grain)
 * @param sharpen      0 (off) .. 1 (strong unsharp-mask, this is the "auto
 *                     enhance / flow" pass that beats the stock camera output)
 * @param aspectRatio  width/height used for the letterboxed cinematic frame,
 *                     null = full sensor ratio (no letterbox)
 * @param fadeBlacks   0..1 lifted-black "film" look (crushes less shadow detail)
 */
data class Preset(
    val id: String,
    val displayName: String,
    val temperature: Float = 0f,
    val tint: Float = 0f,
    val contrast: Float = 1.0f,
    val saturation: Float = 1.0f,
    val exposure: Float = 0f,
    val vignette: Float = 0f,
    val grain: Float = 0f,
    val sharpen: Float = 0.35f,
    val aspectRatio: Float? = null,
    val fadeBlacks: Float = 0f,
    val monochrome: Boolean = false
)

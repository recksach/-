package com.reck.camsansung.camera

import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.GLES20
import android.opengl.Matrix
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.view.Surface
import androidx.camera.core.SurfaceOutput
import androidx.camera.core.SurfaceProcessor
import androidx.camera.core.SurfaceRequest
import com.reck.camsansung.presets.Preset
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executor

/**
 * Runs ONE GL render pass per camera frame and pushes the result to every
 * attached output surface (viewfinder + recorder + still-capture pipeline all
 * pull from this same processor via CameraEffect). Because grading happens
 * once, on the GPU, before the frame is ever encoded, there is no extra
 * compress/decompress round trip -> no quality loss on top of what the sensor
 * already captured.
 */
class ColorGradeSurfaceProcessor : SurfaceProcessor {

    @Volatile
    var currentPreset: Preset = com.reck.camsansung.presets.PresetRepository.STANDARD

    private val glThread = HandlerThread("CamsansungGL").apply { start() }
    private val glHandler = Handler(glThread.looper)

    private val eglCore = EglCore()
    private var program = 0
    private var externalTextureId = 0
    private var inputSurfaceTexture: SurfaceTexture? = null
    private var inputSurface: Surface? = null

    private val outputs = ConcurrentHashMap<SurfaceOutput, OutputTarget>()
    private val texMatrix = FloatArray(16)
    private val startTimeNanos = System.nanoTime()

    private var aPositionLoc = 0
    private var aTexCoordLoc = 0
    private var uTexTransformLoc = 0
    private var uTexelSizeLoc = 0
    private var uTimeLoc = 0
    private var uTemperatureLoc = 0
    private var uTintLoc = 0
    private var uContrastLoc = 0
    private var uSaturationLoc = 0
    private var uExposureLoc = 0
    private var uVignetteLoc = 0
    private var uGrainLoc = 0
    private var uSharpenLoc = 0
    private var uFadeBlacksLoc = 0
    private var uMonochromeLoc = 0

    private data class OutputTarget(
        val surfaceOutput: SurfaceOutput,
        val eglSurface: android.opengl.EGLSurface,
        val width: Int,
        val height: Int
    )

    init {
        glHandler.post {
            eglCore.init()
            // A 1x1 pbuffer-less current context bound purely so we can build
            // the shader program and the external texture up front.
            program = GlUtil.buildProgram(ShaderPrograms.VERTEX_SHADER, ShaderPrograms.FRAGMENT_SHADER)
            externalTextureId = GlUtil.createExternalTexture()
            inputSurfaceTexture = SurfaceTexture(externalTextureId).apply {
                setOnFrameAvailableListener({ onFrameAvailable() }, glHandler)
            }
            inputSurface = Surface(inputSurfaceTexture)
            cacheUniformLocations()
        }
    }

    private fun cacheUniformLocations() {
        aPositionLoc = GLES20.glGetAttribLocation(program, "aPosition")
        aTexCoordLoc = GLES20.glGetAttribLocation(program, "aTextureCoord")
        uTexTransformLoc = GLES20.glGetUniformLocation(program, "uTexTransform")
        uTexelSizeLoc = GLES20.glGetUniformLocation(program, "uTexelSize")
        uTimeLoc = GLES20.glGetUniformLocation(program, "uTime")
        uTemperatureLoc = GLES20.glGetUniformLocation(program, "uTemperature")
        uTintLoc = GLES20.glGetUniformLocation(program, "uTint")
        uContrastLoc = GLES20.glGetUniformLocation(program, "uContrast")
        uSaturationLoc = GLES20.glGetUniformLocation(program, "uSaturation")
        uExposureLoc = GLES20.glGetUniformLocation(program, "uExposure")
        uVignetteLoc = GLES20.glGetUniformLocation(program, "uVignette")
        uGrainLoc = GLES20.glGetUniformLocation(program, "uGrain")
        uSharpenLoc = GLES20.glGetUniformLocation(program, "uSharpen")
        uFadeBlacksLoc = GLES20.glGetUniformLocation(program, "uFadeBlacks")
        uMonochromeLoc = GLES20.glGetUniformLocation(program, "uMonochrome")
    }

    override fun onInputSurface(request: SurfaceRequest) {
        glHandler.post {
            val surface = inputSurface ?: return@post
            inputSurfaceTexture?.setDefaultBufferSize(
                request.resolution.width, request.resolution.height
            )
            request.provideSurface(surface, glHandler::post) { result ->
                Log.d(TAG, "Input surface released: ${result.resultCode}")
            }
        }
    }

    override fun onOutputSurface(surfaceOutput: SurfaceOutput) {
        glHandler.post {
            val surface = surfaceOutput.getSurface(glHandler::post) { event ->
                // Output surface requested removal -> clean up our GL surface.
                outputs.remove(surfaceOutput)?.let { eglCore.destroySurface(it.eglSurface) }
                surfaceOutput.close()
            }
            val size = surfaceOutput.size
            val eglSurface = eglCore.createWindowSurface(surface)
            outputs[surfaceOutput] = OutputTarget(surfaceOutput, eglSurface, size.width, size.height)
        }
    }

    private fun onFrameAvailable() {
        val st = inputSurfaceTexture ?: return
        st.updateTexImage()
        st.getTransformMatrix(texMatrix)

        for (target in outputs.values) {
            drawToTarget(target)
        }
    }

    private fun drawToTarget(target: OutputTarget) {
        eglCore.makeCurrent(target.eglSurface)
        GLES20.glViewport(0, 0, target.width, target.height)
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)

        GLES20.glUseProgram(program)

        // Combine SurfaceTexture's own transform with CameraX's requested
        // output transform (handles rotation/crop/mirroring consistently).
        val combined = FloatArray(16)
        Matrix.setIdentityM(combined, 0)
        target.surfaceOutput.updateTransformMatrix(combined, texMatrix)

        GLES20.glUniformMatrix4fv(uTexTransformLoc, 1, false, combined, 0)
        GLES20.glUniform2f(uTexelSizeLoc, 1f / target.width, 1f / target.height)
        val t = (System.nanoTime() - startTimeNanos) / 1_000_000_000f
        GLES20.glUniform1f(uTimeLoc, t)

        val p = currentPreset
        GLES20.glUniform1f(uTemperatureLoc, p.temperature)
        GLES20.glUniform1f(uTintLoc, p.tint)
        GLES20.glUniform1f(uContrastLoc, p.contrast)
        GLES20.glUniform1f(uSaturationLoc, p.saturation)
        GLES20.glUniform1f(uExposureLoc, p.exposure)
        GLES20.glUniform1f(uVignetteLoc, p.vignette)
        GLES20.glUniform1f(uGrainLoc, p.grain)
        GLES20.glUniform1f(uSharpenLoc, p.sharpen)
        GLES20.glUniform1f(uFadeBlacksLoc, p.fadeBlacks)
        GLES20.glUniform1f(uMonochromeLoc, if (p.monochrome) 1f else 0f)

        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(android.opengl.GLES11Ext.GL_TEXTURE_EXTERNAL_OES, externalTextureId)

        VERTEX_BUFFER.position(0)
        GLES20.glEnableVertexAttribArray(aPositionLoc)
        GLES20.glVertexAttribPointer(aPositionLoc, 2, GLES20.GL_FLOAT, false, 0, VERTEX_BUFFER)

        TEXCOORD_BUFFER.position(0)
        GLES20.glEnableVertexAttribArray(aTexCoordLoc)
        GLES20.glVertexAttribPointer(aTexCoordLoc, 2, GLES20.GL_FLOAT, false, 0, TEXCOORD_BUFFER)

        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)

        eglCore.setPresentationTime(target.eglSurface, System.nanoTime())
        eglCore.swapBuffers(target.eglSurface)
    }

    fun release() {
        glHandler.post {
            outputs.values.forEach { eglCore.destroySurface(it.eglSurface) }
            outputs.clear()
            inputSurfaceTexture?.release()
            inputSurface?.release()
            eglCore.release()
            glThread.quitSafely()
        }
    }

    companion object {
        private const val TAG = "ColorGradeProcessor"

        private val VERTEX_BUFFER = ByteBuffer.allocateDirect(8 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
            put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f))
            position(0)
        }
        private val TEXCOORD_BUFFER = ByteBuffer.allocateDirect(8 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
            put(floatArrayOf(0f, 0f, 1f, 0f, 0f, 1f, 1f, 1f))
            position(0)
        }
    }
}

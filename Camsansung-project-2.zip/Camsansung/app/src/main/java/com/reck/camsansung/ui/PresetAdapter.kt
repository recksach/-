package com.reck.camsansung.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.reck.camsansung.R
import com.reck.camsansung.presets.Preset

class PresetAdapter(
    private val presets: List<Preset>,
    private val onSelected: (Preset) -> Unit
) : RecyclerView.Adapter<PresetAdapter.VH>() {

    private var selectedPosition = 0

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val label: TextView = view.findViewById(R.id.presetLabel)
        val card: View = view.findViewById(R.id.presetCard)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_preset, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val preset = presets[position]
        holder.label.text = preset.displayName
        holder.card.isSelected = position == selectedPosition
        holder.itemView.setOnClickListener {
            val prev = selectedPosition
            selectedPosition = position
            notifyItemChanged(prev)
            notifyItemChanged(selectedPosition)
            onSelected(preset)
        }
    }

    override fun getItemCount(): Int = presets.size
}

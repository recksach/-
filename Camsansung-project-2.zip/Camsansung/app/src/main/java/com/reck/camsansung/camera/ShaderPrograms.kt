package com.reck.camsansung.camera

/**
 * Single GLSL pipeline shared by preview, photo capture and video recording.
 * Order of operations (all in one pass, so there is no re-encode / re-compress
 * step anywhere — this is what avoids "quality loss" the user asked about):
 *   1. sample camera OES texture
 *   2. unsharp-mask sharpen + light denoise blend (the "auto enhance / flow")
 *   3. exposure
 *   4. white balance (temperature/tint)
 *   5. contrast
 *   6. saturation (+ optional monochrome)
 *   7. lifted blacks (film look)
 *   8. vignette
 *   9. film grain (time-seeded noise)
 */
object ShaderPrograms {

    const val VERTEX_SHADER = """
        attribute vec4 aPosition;
        attribute vec4 aTextureCoord;
        uniform mat4 uTexTransform;
        varying vec2 vTextureCoord;
        void main() {
            gl_Position = aPosition;
            vTextureCoord = (uTexTransform * aTextureCoord).xy;
        }
    """

    // Samples the camera OES texture (external, YUV->RGB handled by the driver).
    const val FRAGMENT_SHADER = """
        #extension GL_OES_EGL_image_external : require
        precision highp float;

        varying vec2 vTextureCoord;
        uniform samplerExternalOES sTexture;
        uniform vec2 uTexelSize;     // 1.0 / (width, height) for neighbor sampling
        uniform float uTime;         // seconds, seeds the grain noise

        uniform float uTemperature;  // -1..1
        uniform float uTint;         // -1..1
        uniform float uContrast;     // 0.5..1.6
        uniform float uSaturation;   // 0..2
        uniform float uExposure;     // -1..1
        uniform float uVignette;     // 0..1
        uniform float uGrain;        // 0..1
        uniform float uSharpen;      // 0..1
        uniform float uFadeBlacks;   // 0..1
        uniform float uMonochrome;   // 0 or 1

        float rand(vec2 co) {
            return fract(sin(dot(co, vec2(12.9898, 78.233)) + uTime) * 43758.5453);
        }

        void main() {
            vec4 center = texture2D(sTexture, vTextureCoord);

            // --- 1. Unsharp-mask sharpen + soft denoise blend ---
            vec4 n1 = texture2D(sTexture, vTextureCoord + vec2( uTexelSize.x, 0.0));
            vec4 n2 = texture2D(sTexture, vTextureCoord + vec2(-uTexelSize.x, 0.0));
            vec4 n3 = texture2D(sTexture, vTextureCoord + vec2(0.0,  uTexelSize.y));
            vec4 n4 = texture2D(sTexture, vTextureCoord + vec2(0.0, -uTexelSize.y));
            vec4 blur = (n1 + n2 + n3 + n4 + center) / 5.0;
            vec4 color = center + (center - blur) * (uSharpen * 2.2);
            // gentle denoise: pull slightly back toward the blurred sample to
            // tame the extra noise the sharpen pass introduces
            color = mix(color, blur, 0.08);

            // --- 2. Exposure ---
            color.rgb *= pow(2.0, uExposure * 1.5);

            // --- 3. White balance ---
            color.r += uTemperature * 0.12;
            color.b -= uTemperature * 0.12;
            color.g += uTint * 0.08;
            color.r -= uTint * 0.04;

            // --- 4. Contrast (pivot at mid-gray) ---
            color.rgb = (color.rgb - 0.5) * uContrast + 0.5;

            // --- 5. Saturation / monochrome ---
            float luma = dot(color.rgb, vec3(0.2126, 0.7152, 0.0722));
            vec3 gray = vec3(luma);
            color.rgb = mix(gray, color.rgb, mix(uSaturation, 0.0, uMonochrome));

            // --- 6. Lifted blacks (film) ---
            color.rgb = color.rgb * (1.0 - uFadeBlacks) + uFadeBlacks * 0.06;

            // --- 7. Vignette ---
            vec2 centered = vTextureCoord - vec2(0.5);
            float dist = length(centered) * 1.4;
            float vig = smoothstep(0.85, 0.25, dist * (0.6 + uVignette));
            color.rgb *= mix(1.0, vig, uVignette);

            // --- 8. Film grain ---
            float noise = (rand(vTextureCoord * uTexelSize.x * 500.0) - 0.5) * uGrain * 0.18;
            color.rgb += noise;

            gl_FragColor = vec4(clamp(color.rgb, 0.0, 1.0), center.a);
        }
    """
}

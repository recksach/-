# CameraX / GL classes referenced via reflection-safe defaults; keep as-is.
-keep class androidx.camera.** { *; }
